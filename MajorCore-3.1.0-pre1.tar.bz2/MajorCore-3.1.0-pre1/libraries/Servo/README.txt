= Servo Library for Arduino =
This version is modified for compatibility with MajorCore (Changes to ServoTimers.h)

This library allows an Arduino board to control RC (hobby) servo motors.

For more information about this library please visit us at
http://www.arduino.cc/en/Reference/Servo

== License ==

Copyright (c) 2013 Arduino LLC. All right reserved.
Copyright (c) 2009 Michael Margolis.  All right reserved.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
